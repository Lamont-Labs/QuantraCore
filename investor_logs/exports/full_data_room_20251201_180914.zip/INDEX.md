# QuantraCore Apex — Investor Data Room

**Generated:** 2025-12-01 18:09:14 UTC  
**Documents:** 35

---

## Contents

### Legal

Location: `01_Legal/`

- TERMS_OF_SERVICE.md
- RISK_DISCLOSURES.md
- PRIVACY_POLICY.md
- FEE_SCHEDULE.md
- RISK_LIMITATIONS.md
- COMPLIANCE_POLICIES.md

### Performance

Location: `02_Performance/`

- dd_summary_20251201.json

### Trading

Location: `03_Trading/`


### Compliance

Location: `04_Compliance/`

- attestations_attestations_20251201.jsonl
- attestations_daily_attestation_report_20251201.json

### Risk

Location: `05_Risk/`

- RISK_MANAGEMENT.md

### Models

Location: `06_Models/`

- 12_APEXLAB_AND_APEXCORE_MODELS.md
- 13_PREDICTIVE_LAYER_AND_SAFETY.md
- 21_LABELING_METHODS_AND_LEAKAGE_GUARDS.md
- 22_TRAINING_PROCESS_AND_HYPERPARAMS.md
- 23_EVALUATION_AND_LIMITATIONS.md
- 24_MONSTERRUNNER_EXPLAINED.md

### Technical

Location: `07_Technical/`

- 10_SYSTEM_ARCHITECTURE_DEEP_DIVE.md
- 11_ENGINE_AND_PROTOCOLS.md
- 14_BROKER_AND_EXECUTION_ENVELOPE.md
- 15_APEXDESK_UI_AND_APIS.md
- 20_DATA_SOURCES_AND_UNIVERSE.md
- 32_SECURITY_AND_PROVENANCE.md
- 50_ENGINEERING_OVERVIEW_AND_PRACTICES.md
- 51_TESTING_AND_COVERAGE_SUMMARY.md
- 52_OPERATIONS_AND_RUNBOOKS.md

### Company

Location: `08_Company/`

- 00_EXEC_SUMMARY.md
- 01_ONE_PAGER.md
- 02_FOUNDER_PROFILE.md
- 03_PLATFORM_OVERVIEW.md
- 04_COMPETITIVE_POSITIONING.md
- 05_DEAL_SUMMARY.md
- 40_COMMERCIAL_MODELS_AND_PATHS.md
- 41_TARGET_CUSTOMERS_AND_SEGMENTS.md
- 42_ROADMAP_AND_CAPITAL_USE.md
- 60_INVESTOR_FAQ.md

---

## About This Data Room

This data room contains all documentation and records necessary for 
institutional investor due diligence on QuantraCore Apex.

### Document Categories

1. **Legal** - Terms of service, risk disclosures, privacy policy
2. **Performance** - Historical returns, daily P&L, risk-adjusted metrics
3. **Trading** - Complete trade logs with execution details
4. **Compliance** - Attestations, incident records, policy acknowledgments
5. **Risk** - Risk management documentation, reconciliation records
6. **Models** - ML model documentation, training history, validation results
7. **Technical** - System architecture, security, operations
8. **Company** - Team profiles, business overview, roadmap

### Contact

For questions about this data room:
- Email: investors@quantracore.io

---

*This data room is provided for informational purposes only and does not constitute investment advice.*
